import React, {useEffect, useState} from "react";
import { useParams} from "react-router-dom";
import axios from "axios";

const Pirate = () => {
     const {id} = useParams();
    const [pirate, setPirate] = useState({});

    useEffect(() => {
        axios.get("http://localhost:8000/api/pirates/"+id)
            .then(res => {
                setPirate(res.data);
            })
            .catch(err => console.log(err));
    }, [id]);


    return (
        <div className = "card bg-success p-2 text-dark bg-opacity-25">
            <table className="table table-hover">
                <tbody>  
                    <div>
                        <h1><b>{pirate.name}</b></h1>
                        <tr >
                            <td className = "col-6">
                                <img src={pirate.imagepirate} alt="pirate" className='img-fluid'/>
                            </td>
                            <td className = "col-6">
                                <p><b><h3>About</h3></b></p>
                                <p><b>Position: </b> {pirate.crewPosition}</p>
                                <p><b>Treasures: {pirate.treasure}</b></p>
                                <div>
                                    <p><b>Peg Leg: </b>
                                        {pirate.pegLeg === true ? <p>Yes</p> : <p>No</p>}
                                    </p>
                                </div>
                                <div>
                                    <p><b>Eye Patch: </b>
                                        {pirate.eyePatch === true ? <p>Yes</p> : <p>No</p>}
                                    </p>
                                </div>
                                <div>
                                    <p><b>Hook Hand: </b>
                                        {pirate.hookHand === true ? <p>Yes</p> : <p>No</p>}
                                    </p>
                                </div>
                            </td>    
                        </tr>
                    </div>
                </tbody>
            </table>
            
        </div>
    )
}

export default Pirate;