import React, {useState} from 'react';
import axios from "axios";
import { Link, useHistory } from 'react-router-dom';

const NuevoPirata = () => {

    const [name, setName] = useState("");
    const [imagepirate, setImagepirate] = useState("");
    const [treasure, setTreasure] = useState();
    const [pcatch, setPcatch] = useState("");
    const [crewPosition, setCrewPosition] = useState("");
    const [pegLeg, setPegLeg] = useState(true);
    const [eyePatch, setEyePatch] = useState(true);
    const [hookHand, setHookHand] = useState(true);

    const [errors, setErrors] = useState({});

    const history = useHistory();

    const guardarPirata = e => {
        e.preventDefault();
        axios.post("http://localhost:8000/api/pirates", {
            name,
            imagepirate,
            treasure, 
            pcatch,
            crewPosition,
            pegLeg, 
            eyePatch,
            hookHand
        })
            .then(result => result.data)
            .then(response => {
                console.log(response);
                setErrors({});
                setImagepirate("");
                setTreasure();
                setPcatch("");
                setCrewPosition("");
                setPegLeg("");
                setEyePatch("");
                setHookHand("");
                history.push("/pirates");
            })
            .catch(err => {
                console.log(err.response.data);
                console.log(err.response.data.errors);
                setErrors(err.response.data.errors);
            })
    }

    return(
        <div>
            <div className='navbar bg-success p-2 text-dark bg-opacity-50'>
                <h1>Add Pirate</h1>
                <Link to="/pirates" className="btn btn-info"> Crew Board </Link>
            </div>
            <div className='container bg-success p-2 text-dark bg-opacity-25'>                
                <form onSubmit={guardarPirata}>
                    <div className='row'>
                        <div className='col-6'>
                            <div className='form-group'>
                                <label htmlFor='name'>Pirate Name:</label>
                                <input type="text" id="name" name="name" value={name} onChange={e => setName(e.target.value)} className="form-control"/>
                                {errors.name ? <span className='text-danger'>{errors.name.message}</span> : null}
                            </div>
                            <div className='form-group'>
                                <label htmlFor='imagepirate'>Image URL:</label>
                                <input type="text" id="imagepirate" name="imagepirate" value={imagepirate} onChange={e => setImagepirate(e.target.value)} className="form-control"/>
                                {errors.imagepirate ? <span className='text-danger'>{errors.imagepirate.message}</span> : null}
                            </div>
                            <div className='form-group'>
                                <label htmlFor='treasure'># of Treasure Chests:</label>
                                <input type="number" id="treasure" name="treasure" value={treasure} onChange={e => setTreasure(e.target.value)} className="form-control"/>
                                {errors.treasure ? <span className='text-danger'>{errors.treasure.message}</span> : null}
                            </div>
                            <div className='form-group'>
                                <label htmlFor='pcatch'>Pirate Catch:</label>
                                <input type="text" id="pcatch" name="pcatch" value={pcatch} onChange={e => setPcatch(e.target.value)} className="form-control"/>
                                {errors.pcatch ? <span className='text-danger'>{errors.pcatch.message}</span> : null}
                            </div>
                        </div>
                    
                        <div className="col-6">
                            <div>
                                <p>Crew Position:</p>
                                <select label="crewPosition" className="form-select form-select-lg text-center" value={crewPosition} onChange={e => setCrewPosition(e.target.value)} >
                                    <option value=""></option>
                                    <option value="Captain">Captain</option>
                                    <option value="First Male">First Male</option>
                                    <option value="Quarter Master">Quarter Master</option>
                                    <option value="Bootswain">Bootswain</option>
                                    <option value="Powder Monkey">Powder Monkey</option>
                                </select>
                                {errors.crewPosition ? <span className='text-danger'>{errors.crewPosition.message}</span> : null}
                            </div>
                    
                            <div className='form-group'>
                                <input type="checkbox" className='form-check-input' id="pegLeg" name="pegLeg" checked={pegLeg} onChange={e => setPegLeg(e.target.checked)} />
                                <label className='form-check-label' htmlFor='pegLeg'>
                                    Peg Leg
                                </label>
                            </div>
                            <div className='form-group'>
                                <input type="checkbox" className='form-check-input' id="eyePatch" name="eyePatch" checked={eyePatch} onChange={e => setEyePatch(e.target.checked)} />
                                <label className='form-check-label' htmlFor='eyePatch'>
                                    Eye Patch
                                </label>
                            </div>
                            <div className='form-group'>
                                <input type="checkbox" className='form-check-input' id="hookHand" name="hookHand" checked={hookHand} onChange={e => setHookHand(e.target.checked)} />
                                <label className='form-check-label' htmlFor='hookHand'>
                                    Hook Hand
                                </label>
                            </div>
                            <br/>
                            <input type="submit" className='btn btn-success' value="Add Pirate"/>
                        </div>
                    </div>
                </form>
            </div>
            
        </div>
    )



}

export default NuevoPirata;