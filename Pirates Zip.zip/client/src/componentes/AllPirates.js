import React from "react";
import { useEffect } from "react";
import { useState } from "react";
import { Link, useHistory } from "react-router-dom";
import axios from "axios"

const url = "http://localhost:8000/api/pirates";

const AllPirates = () => {
    const [lista, setLista] = useState([])

    const history = useHistory();


    const get_all = () => {
        axios.get(url)
            .then(result => result.data)
            .then(response => {
                console.log("pirates", response);
                setLista(response);
            })
    }

    useEffect(() => {
        get_all();
    }, [])

    const borrar = (id) => {
        console.log("BORRANDO: ", id);

        axios.delete(url + "/" + id)
            .then(result => result.data)
            .then(response => {
                console.log(response);
                get_all();
            })
    }

    return (
        <div>
            <div className="navbar bg-success p-2 text-dark bg-opacity-50">
                <div>
                    <h1>Pirate Crew</h1>
                    <Link to="/pirate/new" className="btn btn-info" >Add Pirate</Link>
                </div>  
            </div>            
            <div className="container bg-success p-2 text-dark bg-opacity-25">
                <table className="table table-hover">
                    <tbody>
                        {lista.map((item, index) => {
                            return (
                                <tr key={item.name + index}>
                                    <td className="col-3"><b>{item.name}</b></td>
                                    <td className="col-6">
                                        <img src={item.imagepirate} alt="pirate" className='img-fluid'/>
                                    </td>
                                    <td className="col-3">
                                        <Link to={`/pirates/${item._id}`} 
                                        className="btn btn-primary"> View Pirate </Link>
                                    </td>
                                    <td>
                                        <button className="btn btn-danger" onClick={() => borrar(item._id)} >Walk The Plank</button>
                                    </td>
                                </tr>
                            )
                        })}
                        
                    </tbody>
                </table>             
            </div>       
        </div>
    );

}


export default AllPirates;