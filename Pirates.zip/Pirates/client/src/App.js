import { BrowserRouter, Route, Switch } from "react-router-dom";
import NewPirate from "./componentes/NewPirate";
import Pirate from "./componentes/Pirate";
import AllPirates from "./componentes/AllPirates";


function App() {
  return (
    <div className="container">
      <BrowserRouter>

        <Switch>
          <Route path="/pirates" exact render={() => <AllPirates />} />
          <Route path="/pirate/new" exact render={() => <NewPirate />} />
          <Route path="/pirates/:id" exact render={(routeProps) => <Pirate {...routeProps} />} />
        </Switch>

</BrowserRouter>
    </div>
  );
}

export default App;
